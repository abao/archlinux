The buttons.bmp comes into the bbLeanSkin folder wich is located in the plugins folder of your bblean folder.

Just want to say folder one more time :D Folder.