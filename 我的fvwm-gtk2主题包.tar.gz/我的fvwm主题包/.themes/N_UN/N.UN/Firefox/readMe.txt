Within this packs are two files:

With_Icons_userChrome.css: Just fixes the color of some elements. 
Without_Icons_userChrome.css: Does the same as the With_Icons_userChrome.css, but also removes all icons.


How to Use:

Just rename the file of your choice to userChrome.css and copy it to your profil folder.