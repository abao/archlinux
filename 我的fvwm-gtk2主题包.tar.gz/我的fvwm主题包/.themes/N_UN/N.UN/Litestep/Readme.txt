If you rightclick on the n.un logo you get the option menu.

Fell free to use this skin as a base for your own and have fun with it ;)