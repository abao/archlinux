-------( Install )-------

This theme is designed for the Pidgin Screenlet by meek.
download here: http://gnome-look.org/content/show.php/PidginScreenlet?content=72611

Read more about screenlets here: http://www.screenlets.org/

To install this theme you just need to copy the content of the 'themes' folder to the 'themes' folder of the Pidgin Screenlet. For example:

 cp themes/DeepBlack ~/.screenlets/Pidgin/themes/  
