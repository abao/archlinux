-------( Icons )-------

I've included media-control-icons for gtk that matches the Neutronium DeepBlack Style.
To use them just copy the content of the 'icons' folder to the theme dir of your current icon-theme (~/.icons/*theme*).




-------( Firefox )-------

If web forms and controls appear dark and unreadable you need to add the provided file "userContent.css" to the "chrome/" subfolder in your Firefox profile. It contains settings to get the default colors back.
Install the theme with Gnome Theme Manager and type the following in a terminal:

mv ~/.themes/Neutronium DeepBlack/userContent.css ~/.mozilla/firefox/*.default/chrome/

Note that the place of the chrome directory may vary on different Linux distributions.




-------( Pidgin )-------

Actually I never had that issue but if you have black text on black background in gaim/pidgin do the following:
Create a file named "gtkrc-2.0" in .purple dir in your home and put the following in it:

style "Custom"
{
base[NORMAL] = "#353535"
}
class "GtkWidget" style "Custom"




-------( Open Office )-------

To get a white document background color instead of black, go to:

Tools > Options > OpenOffice.org > Appearance > Custom Colors > Document background

For dark themes Open Office 2 uses a high contrast icon theme (due to automatic icon settings). If you don't like this, do the following:

1. Open "Tools -> Options dialog -> OpenOffice.org -> View"

2. Change the icon theme from automatic/null to a different one.




-------( Ubuntu )-------

If you are using Ubuntu and buttons look wierd, it's necessary to install the package "gtk2-engines-pixbuf”. Type in a terminal:

sudo apt-get install gtk2-engines-pixbuf

The same is valid for all the themes based on the engine "pixmap".




[thx to wulax for the specific program settings]
