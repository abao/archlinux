-------(Install)-------
Copy the file 'Deep Black.kcsrc' to '~/.kde/share/apps/kdisplay/color-schemes/'. The color-scheme will now be available in kcontrol.

-->
cp Deep\ Black.kcsrc ~/.kde/share/apps/kdisplay/color-schemes/
