This theme is designed for the mumbles notification system.

Read more about mumbles here: http://www.mumbles-project.org/
